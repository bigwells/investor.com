<table style="width:100%;max-width:620px;margin:0 auto;background-color:#ffffff;">
    <tbody>
    <tr>
        <td style="padding: 10 20px 20px">
            <p style="margin-bottom: 10px;"><strong>{{ $data['greeting'] }}</strong></p>
            <div style="margin-bottom: 10px;">{!! auto_p($data['message']) !!}</div>
        </td>
    </tr>
    </tbody>
</table>
