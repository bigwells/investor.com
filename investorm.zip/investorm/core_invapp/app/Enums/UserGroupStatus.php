<?php


namespace App\Enums;


interface UserGroupStatus
{
    const SHOW = 'show';
    const HIDE = 'hide';
}
