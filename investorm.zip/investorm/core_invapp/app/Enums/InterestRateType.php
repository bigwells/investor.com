<?php


namespace App\Enums;

interface InterestRateType
{
    const PERCENT = 'percent';
    const FIXED = 'fixed';
}
