<?php


namespace App\Enums;

interface WithdrawMethodStatus
{
    const ACTIVE = 'active';
    const INACTIVE = 'inactive';
}
