<?php


namespace App\Enums;

interface RefundType
{
    const TOTAL = 'total';
    const PARTIAL = 'partial';
}
