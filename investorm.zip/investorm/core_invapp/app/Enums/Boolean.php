<?php


namespace App\Enums;

interface Boolean
{
    const YES = 1;
    const NO = 0;
}
