<?php


namespace App\Enums;

interface SchemeStatus
{
    const ACTIVE = 'active';
    const INACTIVE = 'inactive';
    const ARCHIVED = 'archived';
    const DELETE = 'delete';
}
