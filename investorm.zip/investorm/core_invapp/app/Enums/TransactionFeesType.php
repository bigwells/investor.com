<?php


namespace App\Enums;

interface TransactionFeesType
{
    const FLAT = 'flat';
    const PERCENTAGE = 'percent';
}
