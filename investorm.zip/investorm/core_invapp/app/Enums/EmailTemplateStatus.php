<?php


namespace App\Enums;

interface EmailTemplateStatus
{
    const ACTIVE = 'active';
    const INACTIVE = 'inactive';
}
